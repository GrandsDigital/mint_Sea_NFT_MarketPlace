import React, { useEffect, useState, useContext, useRef, createRef } from 'react';
import { useParams, Link, useHistory } from 'react-router-dom';
import { useToasts } from 'react-toast-notifications';
import web3 from '../connection/web3';
import ItemThumbnail from './item/ItemThumbnail';
import ItemInfoPanel from './item/ItemInfoPanel';
import ItemAuthor from './item/ItemAuthor';
import { formatPrice } from '../helpers/utils';
import Web3Context from '../store/web3-context';
import CollectionContext from '../store/collection-context';
import MarketplaceContext from '../store/marketplace-context';
import Loader from './general/Loader';
import FullScreenLoader from './general/FullScreenLoader';
import NFTCollection from '../contracts/NFTCollection.json';
import assert from 'assert';
import { SiBinance } from 'react-icons/si';
import { FaEthereum } from 'react-icons/fa';

function ItemSingle(props) {
    const collectionCtx = useContext(CollectionContext);
    const marketplaceCtx = useContext(MarketplaceContext);
    const web3Ctx = useContext(Web3Context);
    const [assetHistory, setAssetHistory] = useState([]);
    const { addToast } = useToasts();
    const [currentAsset, setCurrentAsset] = useState([]);
    const { id } = useParams();

    let history = useHistory()
    useEffect(() => {

        setAssetHistory(history.location.state.state)
    }, [])

    console.log("history", history.location.state.state)


    // useEffect(() => {
    //     async function getAssetHistory() {
    //         const networkId = await web3Ctx.loadNetworkId(web3);
    //         const nftDeployedNetwork = NFTCollection.networks[networkId];
    //         const nftContract = collectionCtx.loadContract(web3, NFTCollection, nftDeployedNetwork);
    //         const itemHistory = await nftContract.methods.getTrack(id).call();
    //         setAssetHistory(itemHistory);
    //         console.log(itemHistory);
    //     }

    //     getAssetHistory();

    // }, []);

    const priceRefs = useRef([]);
    if (priceRefs.current.length !== collectionCtx.collection.length) {
        priceRefs.current = Array(collectionCtx.collection.length)
            .fill()
            .map((_, i) => priceRefs.current[i] || createRef());
    }

    const makeOfferHandler = (event, id, nftKey) => {
        event.preventDefault();

        const enteredPrice = web3.utils.toWei(priceRefs.current[nftKey].current.value, 'ether');

        collectionCtx.contract.methods
            .approve(marketplaceCtx.contract.options.address, id)
            .send({ from: web3Ctx.account })
            .on('transactionHash', (hash) => {
                marketplaceCtx.setMktIsLoading(true);
            })
            .on('receipt', (receipt) => {
                marketplaceCtx.contract.methods
                    .makeOffer(id, enteredPrice)
                    .send({ from: web3Ctx.account })
                    .on('error', (error) => {
                        addToast('Something went wrong when pushing to the blockchain', {
                            appearance: 'error',
                        });
                        marketplaceCtx.setMktIsLoading(false);
                    });
            });
    };

    const buyHandler = (event) => {
        const buyIndex = parseInt(event.target.value);
        marketplaceCtx.contract.methods
            .fillOffer(marketplaceCtx.offers[buyIndex].offerId)
            .send({ from: web3Ctx.account, value: marketplaceCtx.offers[buyIndex].price })
            .on('transactionHash', (hash) => {
                marketplaceCtx.setMktIsLoading(true);
            })
            .on('error', (error) => {
                addToast('Something went wrong when pushing to the blockchain', {
                    appearance: 'error',
                });
                marketplaceCtx.setMktIsLoading(false);
            });
    };

    const cancelHandler = (event) => {
        const cancelIndex = parseInt(event.target.value);
        marketplaceCtx.contract.methods
            .cancelOffer(marketplaceCtx.offers[cancelIndex].offerId)
            .send({ from: web3Ctx.account })
            .on('transactionHash', (hash) => {
                marketplaceCtx.setMktIsLoading(true);
            })
            .on('error', (error) => {
                addToast('Something went wrong when pushing to the blockchain', {
                    appearance: 'error',
                });
                marketplaceCtx.setMktIsLoading(false);
            });
    };

    useEffect(() => {
        document.title = 'Item Details | NFT Marketplace';
    }, []);

    useEffect(() => {
        setCurrentAsset(collectionCtx.collection.filter((asset) => asset.id === parseInt(id)));

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [collectionCtx.collection]);

    return (
        <>
            {/* {assert.length ==0 ? <FullScreenLoader heading='loading' /> : null} */}
            <section className='py-5 mt-2'>
                {assetHistory.length == 0 ? (
                    <div className='py-5 text-center mt-5'>
                        <h1 className='h2 mt-5'>Fetching item details</h1>
                        <p className='text-muted'>Please wait until we prepare your data.</p>
                        <Loader />
                    </div>
                ) : (
                    // currentAsset.map((asset, key) => {
                    // const index = marketplaceCtx.offers
                    //     ? marketplaceCtx.offers.findIndex((offer) => offer.id === asset.id)
                    //     : -1;
                    // const owner = index === -1 ? asset.owner : marketplaceCtx.offers[index].user;
                    // const price = index !== -1 ? formatPrice(marketplaceCtx.offers[index].price).toFixed(2) : null;

                    // return (
                    <div >
                        <div className='bg-dark py-4 mt-4'>
                            <div className='container'>
                                <nav aria-label='breadcrumb'>
                                    <ol className='breadcrumb'>
                                        <li className='breadcrumb-item'>
                                            <Link
                                                className='text-decoration-none d-flex align-items-center'
                                                to='/'
                                            >
                                                {' '}
                                                <i className='las la-home la-sm me-1'></i>Home
                                            </Link>
                                        </li>
                                        <li className='breadcrumb-item'>
                                            <Link
                                                className='text-decoration-none d-flex align-items-center'
                                                to='/explore'
                                            >
                                                {' '}
                                                <i className='las la-icons la-sm me-1'></i>Explore
                                            </Link>
                                        </li>
                                        <li className='breadcrumb-item active' aria-current='page'>
                                            {assetHistory.title}
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                        <div className='container py-5'>
                            <div className='row mb-4 gy-4 mt-4'>
                                <div className='col-lg-6'>
                                    {/* <ItemThumbnail thumbnail={`https://ipfs.infura.io/ipfs/${asset.img}`} /> */}
                                    <ItemThumbnail thumbnail={assetHistory.url} type={assetHistory.sold} />
                                </div>
                                <div className='col-lg-6'>
                                    {/* <ItemInfoPanel
                                                name={asset.title}
                                                category={asset.category}
                                                img={`https://ipfs.infura.io/ipfs/${asset.img}`}
                                                creator={assetHistory[0]}
                                                description={asset.description}
                                                dateCreated={asset.dateCreated}
                                            /> */}
                                    <ItemInfoPanel
                                        name={assetHistory.name}
                                        category={assetHistory.category}
                                        img={assetHistory.url}
                                        creator={assetHistory}
                                        // description={assetHistory.description}
                                        dateCreated={assetHistory.edate}
                                    />

                                    <ItemAuthor creator={assetHistory} owner={assetHistory.owner} />

                                    <div className='gy-4 my-4'>
                                        <h6 className='mb-3'>Price</h6>
                                        {assetHistory.price ? (
                                            <div className='text-sm text-muted fw-normal mb-0 d-flex align-items-center'>
                                                <span className='icon bg-primary text-white me-2'>
                                                    {assetHistory.Blockchain == "Binance" ? (
                                                        <SiBinance className="fa-brands fa-ethereum" />
                                                    ) : assetHistory.Blockchain === "Ethereum" ? (
                                                        <FaEthereum />
                                                    ) : (
                                                        <>
                                                            <svg
                                                                fill="white"
                                                                viewBox="0 0 24 24"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                style={{ width: "18px", height: "20px" }}
                                                            >
                                                                <path
                                                                    d="M16.5828 8.90039C16.2516 8.70599 15.8196 8.70599 15.4524 8.90039L12.8604 10.4016L11.1 11.3808L8.508 12.882C8.1768 13.0764 7.7448 13.0764 7.3776 12.882L5.3184 11.7084C4.9872 11.514 4.7532 11.154 4.7532 10.7616V8.44679C4.7532 8.05439 4.9512 7.69799 5.3184 7.49999L7.3452 6.35879C7.6764 6.16439 8.1084 6.16439 8.4756 6.35879L10.5024 7.49999C10.8336 7.69439 11.0676 8.05439 11.0676 8.44679V9.94799L12.828 8.93639V7.43519C12.828 7.04279 12.63 6.68639 12.2628 6.48839L8.5116 4.33559C8.1804 4.14119 7.7484 4.14119 7.3812 4.33559L3.5652 6.48839C3.198 6.68279 3 7.04279 3 7.43519V11.7732C3 12.1656 3.198 12.522 3.5652 12.72L7.3848 14.8728C7.716 15.0672 8.148 15.0672 8.5152 14.8728L11.1072 13.404L12.8676 12.3924L15.4596 10.9236C15.7908 10.7292 16.2228 10.7292 16.59 10.9236L18.6168 12.0648C18.948 12.2592 19.182 12.6192 19.182 13.0116V15.3264C19.182 15.7188 18.984 16.0752 18.6168 16.2732L16.59 17.4468C16.2588 17.6412 15.8268 17.6412 15.4596 17.4468L13.4328 16.3056C13.1016 16.1112 12.8676 15.7512 12.8676 15.3588V13.8576L11.1072 14.8692V16.3704C11.1072 16.7628 11.3052 17.1192 11.6724 17.3172L15.492 19.47C15.8232 19.6644 16.2552 19.6644 16.6224 19.47L20.442 17.3172C20.7732 17.1228 21.0072 16.7628 21.0072 16.3704V12.0324C21.0072 11.64 20.8092 11.2836 20.442 11.0856L16.5828 8.90039Z"
                                                                    fill="white"
                                                                ></path>
                                                            </svg>
                                                        </>
                                                    )}
                                                    {/* <i className='lab la-ethereum fa-fw'></i> */}
                                                </span>
                                                <p className='mb-0 h4 d-flex align-items-end fw-normal text-white ms-2'>
                                                    {assetHistory.price} <span className='ms-2 text-muted small'>

                                                        {assetHistory.Blockchain == "Binance"
                                                            ? "BNB"
                                                            : assetHistory.Blockchain === "Ethereum"
                                                                ? "ETH"
                                                                : "MATIC"}
                                                    </span>
                                                </p>
                                            </div>
                                        ) : (
                                            <p className='text-muted mb-0'>This item is not for sale!</p>
                                        )}
                                    </div>

                                    {1 !== -1 ? (
                                        assetHistory.owner !== web3Ctx.account ? (
                                            <button
                                                type='button'
                                                className='btn btn-gradient-primary px-5'
                                                value={1}
                                                onClick={buyHandler}
                                            >
                                                Buy Item
                                            </button>
                                        ) : (
                                            <button
                                                type='button'
                                                // value={index}
                                                className='btn btn-danger px-5'
                                                onClick={cancelHandler}
                                            >
                                                Cancel Offer
                                            </button>
                                        )
                                    ) : assetHistory.owner === web3Ctx.account ? (
                                        <div className='col-xl-8'>
                                            <form
                                                className='input-group'
                                                onSubmit={(e) => makeOfferHandler()}
                                            >
                                                <button
                                                    type='submit'
                                                    className='btn btn-primary rounded-sm me-2'
                                                >
                                                    Offer
                                                </button>
                                                <input
                                                    type='number'
                                                    step='0.001'
                                                    min='0.0000000000000000000000001'
                                                    placeholder='ETH...'
                                                    className='form-control py-1 rounded-sm bg-dark'
                                                // ref={priceRefs.current[key]}
                                                />
                                            </form>
                                        </div>
                                    ) : null}
                                </div>
                            </div>
                        </div>
                    </div>
                    // );
                    // })
                )}
            </section>
        </>
    );
}

export default ItemSingle;
