import React, { useEffect, useState } from "react";
import Web3Modal from "web3modal";
import WalletConnect from "@walletconnect/web3-provider";
import CoinbaseWalletSDK from '@coinbase/wallet-sdk';
import useWeb3 from "../Components/useWeb3";
import Web3 from "web3";
import { useDispatch } from "react-redux";
import { Web3_Call, setChain_id, setWeb3_Provider } from "../../Redux/ChainID";

let binanceTestChainId = 97
binanceTestChainId = binanceTestChainId.toString(16)
let SepoliaTestChainId = 11155111
SepoliaTestChainId = SepoliaTestChainId.toString(16)
let PolygonTestChainId = 80001
PolygonTestChainId = PolygonTestChainId.toString(16)

const getProviderOptions = () => {
    // const infuraId = "00ca1859789d4b40bce01f4104844224";
    const providerOptions = {
        walletconnect: {
            package: WalletConnect,
            options: {
                network: "binance",
                infuraId: "https://mainnet.infura.io/v3/00ca1859789d4b40bce01f4104844224`",
                rpc: {
                    56: "https://mainnet.infura.io/v3/00ca1859789d4b40bce01f4104844224`"
                }
            }
        },
        coinbasewallet: {
            package: CoinbaseWalletSDK, // Required
            options: {
                appName: "Red Giant Staking", // Required
                infuraId: "00ca1859789d4b40bce01f4104844224", // Required
                rpc: "https://polygon-testnet.public.blastapi.io", // Optional if `infuraId` is provided; otherwise it's required
                chainId: 80001, // Optional. It defaults to 1 if not provided
                darkMode: true // Optional. Use dark theme, defaults to false
            }
        },

        "custom-binancechainwallet": {
            display: {
                logo: "https://lh3.googleusercontent.com/rs95LiHzLXNbJdlPYwQaeDaR_-2P9vMLBPwaKWaQ3h9jNU7TOYhEz72y95VidH_hUBqGXeia-X8fLtpE8Zfnvkwa=w128-h128-e365-rj-sc0x00ffffff",
                name: "Binance Chain Wallet",
                description: "Connect to your Binance Chain Wallet"
            },
            package: true,
            connector: async () => {

                let provider = null;
                if (typeof window.BinanceChain !== 'undefined') {
                    provider = window.BinanceChain;
                    try {
                        const account = await provider.request({ method: 'eth_requestAccounts' })
                        console.log(account[0]);
                    } catch (error) {
                        throw new Error("User Rejected");
                    }
                } else {
                    throw new Error("No Binance Chain Wallet found");
                }
                return provider;
            }
        },
    };
    return providerOptions;
};




export const web3Context = React.createContext();


export const Web3ContextProvider = ({
    children,
}) => {
    // const [curSocket, setCurSocket] = useState<Socket>({} as Socket);
    const [web3, setWeb3] = useState();
    const [walletAddress, setWalletAddress] = useState("");
    const [provider, setprovider] = useState("")
    const [ShowData, setShowData] = useState([])
    const [Filter_ShowData, setFilter_ShowData] = useState([])

    const [Spinner, setSpinner] = useState(false)
    const dispatch = useDispatch()
    const web3Modal = new Web3Modal({
        network: "Polygon",
        cacheProvider: true,
        providerOptions: getProviderOptions(),
    });




    const resetApp = async () => {
        // const { web3 } = web3Data;
        if (web3 && web3.currentProvider && web3.currentProvider.close) {
            await web3.currentProvider.close();
        }
        setWalletAddress("");
        await web3Modal.clearCachedProvider();
        // setWeb3Data({ ...INITIAL_STATE });
    };

    useEffect(() => {
        if (web3Modal.cachedProvider) {
            resetApp();
        }
    }, []);


    const subscribeProvider = async (provider) => {

        if (!provider.on) {
            return;
        }
        setprovider(provider)
        provider.on("close", () => resetApp());
        provider.on("accountsChanged", async (accounts) => {
            console.log(accounts[0]);
            setWalletAddress(accounts[0]);
            // setWeb3Data({ ...web3Data, address: accounts[0] });
            // await this.getAccountAssets();
        });
        provider.on("chainChanged", async (chainId) => {
            // const { web3 } = web3Data;
            // const networkId = await web3.eth.net.getId();
            // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
            // await this.getAccountAssets();
        });

        provider.on("networkChanged", async (networkId) => {
            // const { web3 } = web3Data;
            // const chainId = await web3.eth.chainId();
            // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
            // await this.getAccountAssets();
        });
    };



    const onConnect = async () => {
        try {

      
            const provider = await web3Modal.connect();
            await subscribeProvider(provider);
            await provider.enable();
            setWeb3(new Web3(provider));

            // dispatch(Web3_Call(new Web3(provider)))
            const chainId = await provider.request({ method: 'eth_chainId' });
            dispatch(setChain_id(chainId))

            if (chainId === `0x${binanceTestChainId}` || chainId === `0x${SepoliaTestChainId}` || chainId === `0x${PolygonTestChainId}`) {
                console.log("Bravo!, you are on the correct network");
            } else {
                try {

                    // const web3 = window.web3;
                    await provider.request({
                        method: 'wallet_switchEthereumChain',
                        params: [{ chainId: `0x${binanceTestChainId}` }], //0x38 Mainnet 
                    });
                    console.log("You have succefully switched to Binance main network")
                } catch (switchError) {
                    // This error code indicates that the chain has not been added to MetaMask.
                    if (switchError.code === 4902) {
                        try {
                            await provider.request({
                                method: 'wallet_addEthereumChain',
                                params: [
                                    {
                                        chainId: `0x${binanceTestChainId}`,
                                        chainName: 'Binance Smart Chain',
                                        rpcUrls: ['https://bsc-testnet.public.blastapi.io'],
                                        blockExplorerUrls: ['https://bscscan.com/'],
                                        nativeCurrency: {
                                            symbol: 'BNB',
                                            decimals: 18,
                                        }
                                    }
                                ]
                            });
                        } catch (addError) {
                            console.log(addError);
                            // alert(addError);
                        }
                    }
                    // alert("Failed to switch to the network")
                    return;
                }
            }

            const accounts = await provider.request({ method: 'eth_requestAccounts' });
            const account = accounts[0];
            console.log("Account", account);
            setWalletAddress(account);
        } catch (e) {
            console.log(e);
        }
    };

    return (
        <web3Context.Provider
            value={{
                web3,
                walletAddress,
                setWeb3,
                setWalletAddress,
                onConnect, resetApp, setFilter_ShowData, Filter_ShowData, provider, setSpinner, setShowData, ShowData, Spinner
            }}
        >
            {children}
        </web3Context.Provider>
    );
};
