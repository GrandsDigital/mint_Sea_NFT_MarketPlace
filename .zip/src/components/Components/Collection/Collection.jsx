import React from 'react'
import './Collection.css'

export default function Collection() {
  return (
    <div>
        

    </div>
  )
}
