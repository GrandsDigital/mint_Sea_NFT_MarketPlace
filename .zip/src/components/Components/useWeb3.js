import { useContext } from "react";
import { web3Context } from "./web3Context";

const useWeb3 = () => {
    const { web3, setWeb3, walletAddress, setWalletAddress,onConnect,provider,resetApp,setSpinner,setShowData,ShowData,Spinner,Filter_ShowData,setFilter_ShowData, } = useContext(web3Context);
    return {
        web3,
        walletAddress,
        setWeb3,
        setWalletAddress,onConnect,resetApp,provider,setSpinner,Filter_ShowData,setFilter_ShowData,setShowData,ShowData,Spinner
    };
};

export default useWeb3;
