import React, { useEffect } from "react";
import Web3 from "web3";
import Web3Modal from "web3modal";
import WalletConnect from "@walletconnect/web3-provider";
import CoinbaseWalletSDK from '@coinbase/wallet-sdk';
import useWeb3 from "../useWeb3";

const getProviderOptions = () => {
  // const infuraId = "00ca1859789d4b40bce01f4104844224";
  const providerOptions = {
      walletconnect: {
          package: WalletConnect,
          options: {
              network: "binance",
              rpc: {
                  97: "https://bsc-testnet.public.blastapi.io"
              }
          }
      },
      coinbasewallet: {
          package: CoinbaseWalletSDK, // Required
          options: {
              appName: "Red Giant Staking", // Required
              infuraId: "", // Required
              rpc: "https://bsc-testnet.public.blastapi.io", // Optional if `infuraId` is provided; otherwise it's required
              chainId: 97, // Optional. It defaults to 1 if not provided
              darkMode: false // Optional. Use dark theme, defaults to false
          }
      },
      coinbasewallet: {
        package: CoinbaseWalletSDK, // Required
        options: {
            appName: "Red Giant Staking", // Required
            infuraId: "", // Required
            rpc: "https://bsc-testnet.public.blastapi.io", // Optional if `infuraId` is provided; otherwise it's required
            chainId: 97, // Optional. It defaults to 1 if not provided
            darkMode: false // Optional. Use dark theme, defaults to false
        }
    },
      "custom-binancechainwallet": {
          display: {
              logo: "https://lh3.googleusercontent.com/rs95LiHzLXNbJdlPYwQaeDaR_-2P9vMLBPwaKWaQ3h9jNU7TOYhEz72y95VidH_hUBqGXeia-X8fLtpE8Zfnvkwa=w128-h128-e365-rj-sc0x00ffffff",
              name: "Binance Chain Wallet",
              description: "Connect to your Binance Chain Wallet"
          },
          package: true,
          connector: async () => {
              let provider = null;
              if (typeof window.BinanceChain !== 'undefined') {
                  provider = window.BinanceChain;
                  try {
                      const account = await provider.request({ method: 'eth_requestAccounts' })
                      console.log(account[0]);
                  } catch (error) {
                      throw new Error("User Rejected");
                  }
              } else {
                  throw new Error("No Binance Chain Wallet found");
              }
              return provider;
          }
      },
  };
  return providerOptions;
};
export default function Header({setnavOpen,setgetAddress}) {
  const { web3, setWeb3, walletAddress, setWalletAddress } = useWeb3();

  const web3Modal = new Web3Modal({
      network: "Binance",
      cacheProvider: true,
      providerOptions: getProviderOptions(),
  });

  useEffect(() => {
      if (web3Modal.cachedProvider) {
          resetApp();
      }
  }, []);

  const subscribeProvider = async (provider) => {
      if (!provider.on) {
          return;
      }
      provider.on("close", () => resetApp());
      provider.on("accountsChanged", async (accounts) => {
          console.log(accounts[0]);
          setWalletAddress(accounts[0]);
          // setWeb3Data({ ...web3Data, address: accounts[0] });
          // await this.getAccountAssets();
      });
      provider.on("chainChanged", async (chainId) => {
          // const { web3 } = web3Data;
          // const networkId = await web3.eth.net.getId();
          // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
          // await this.getAccountAssets();
      });

      provider.on("networkChanged", async (networkId) => {
          // const { web3 } = web3Data;
          // const chainId = await web3.eth.chainId();
          // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
          // await this.getAccountAssets();
      });
  };

  const resetApp = async () => {
      // const { web3 } = web3Data;
      if (web3 && web3.currentProvider && web3.currentProvider.close) {
          await web3.currentProvider.close();
      }
      setWalletAddress("");
      await web3Modal.clearCachedProvider();
      // setWeb3Data({ ...INITIAL_STATE });
  };

  const onConnect = async () => {
      try {
          const provider = await web3Modal.connect();
          await subscribeProvider(provider);
          await provider.enable();
          setWeb3(new Web3(provider));
          const chainId = await provider.request({ method: 'eth_chainId' });
          const binanceTestChainId = '0x38'
          if (chainId === binanceTestChainId) {
              console.log("Bravo!, you are on the correct network");
          } else {
              try {
                  await provider.request({
                      method: 'wallet_switchEthereumChain',
                      params: [{ chainId: '0x38' }],
                  });
                  console.log("You have succefully switched to Binance main network")
              } catch (switchError) {
                  // This error code indicates that the chain has not been added to MetaMask.
                  if (switchError.code === 4902) {
                      try {
                          await provider.request({
                              method: 'wallet_addEthereumChain',
                              params: [
                                  {
                                      chainId: '0x38',
                                      chainName: 'Binance Smart Chain',
                                      rpcUrls: ['https://bsc-testnet.public.blastapi.io'],
                                      blockExplorerUrls: ['https://bscscan.com/'],
                                      nativeCurrency: {
                                          symbol: 'BNB',
                                          decimals: 18,
                                      }
                                  }
                              ]
                          });
                      } catch (addError) {
                          console.log(addError);
                          // alert(addError);
                      }
                  }
                  // alert("Failed to switch to the network")
                  return;
              }
          }

          const accounts = await provider.request({ method: 'eth_requestAccounts' });
          const account = accounts[0];
          setWalletAddress(account);
      } catch (e) {
          console.log(e);
      }
  };

  function ellipseAddress(
      address = "",
      width = 10
  ) {
      return `${address.slice(0, width)}...${address.slice(-width)}`;
  }
  return (
    <div>
      {/* <div className="flex flex-col flex-1 w-full"> */}
        <header className="z-40 py-4 bg-white shadow-bottom dark:bg-gray-800">
          <div className="container flex items-center justify-between h-full px-6 mx-auto text-purple-600 dark:text-purple-300">
            <button
              className="p-1 mr-5 -ml-1 rounded-md lg:hidden focus:outline-none focus:shadow-outline-purple"
              aria-label="Menu"
              onClick={() => setnavOpen((current) => !current)}
            >
              <svg
                fill="currentColor"
                viewBox="0 0 20 20"
                className="w-6 h-6"
                aria-hidden="true"
              >
                <path
                  fillRule="evenodd"
                  d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                  clipRule="evenodd"
                />
              </svg>
            </button>
            <div className="flex justify-center flex-1 lg:mr-32">
              <div className="relative w-full max-w-xl mr-6 focus-within:text-purple-500">
                <div className="absolute inset-y-0 flex items-center pl-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
                <input
                  className="block w-full text-sm focus:outline-none dark:text-gray-300 form-input leading-5 focus:border-purple-400 dark:border-gray-600 focus:shadow-outline-purple dark:focus:border-gray-600 dark:focus:shadow-outline-gray dark:bg-gray-700 pl-8 text-gray-700"
                  type="text"
                  placeholder="Paste your address here"
                  aria-label="Search"
                  defaultValue=""
                  onChange={(e)=>setgetAddress(e.target.value)}
                />
              </div>
            </div>

            <button className="btn btn-primary connect-wallet" data-bss-hover-animate="pulse" type="button" onClick={walletAddress === "" ? onConnect : resetApp} >{walletAddress === "" ? "Connect Wallet" : ellipseAddress(walletAddress, 7)}</button>

            {/* <ul className="flex items-center flex-shrink-0 space-x-6">
              <li className="flex">
                <button
                  className="rounded-md focus:outline-none focus:shadow-outline-purple"
                  aria-label="Toggle color mode"
                >
                  <svg
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    className="w-5 h-5"
                    aria-hidden="true"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </li>
            </ul> */}
          </div>
        </header>
      {/* </div> */}

     
    </div>
  );
}
