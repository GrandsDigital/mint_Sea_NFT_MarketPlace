import React, { useEffect, useState, useContext } from 'react';
import { useToasts } from 'react-toast-notifications';
import { Link, NavLink } from 'react-router-dom';
import { navbarChangeStyle } from '../../helpers/utils';
import Web3Context from '../../store/web3-context';
import MarketplaceContext from '../../store/marketplace-context';
// import web3 from '../../connection/web3';
import { formatPrice, configEtherScanUrl } from '../../helpers/utils';
import { Jazzicon } from '@ukstv/jazzicon-react';
import Web3 from "web3";
import Web3Modal from "web3modal";
import WalletConnect from "@walletconnect/web3-provider";
import CoinbaseWalletSDK from '@coinbase/wallet-sdk';
import useWeb3 from "../Components/useWeb3";
import { useSelector } from 'react-redux';
import axios from 'axios';
import { Avatar } from '@mui/material';

// const getProviderOptions = () => {
//   // const infuraId = "00ca1859789d4b40bce01f4104844224";
//   const providerOptions = {
//       walletconnect: {
//           package: WalletConnect,
//           options: {
//               network: "binance",
//               infuraId: "00ca1859789d4b40bce01f4104844224",
//               rpc: {
//                   [56] : "https://endpoints.omniatech.io/v1/bsc/testn"
//               }
//           }
//       },
//       coinbasewallet: {
//           package: CoinbaseWalletSDK, // Required
//           options: {
//               appName: "Red Giant Staking", // Required
//               infuraId: "00ca1859789d4b40bce01f4104844224", // Required
//               rpc: "https://bsc-dataseed.binance.org", // Optional if `infuraId` is provided; otherwise it's required
//               chainId: 56, // Optional. It defaults to 1 if not provided
//               darkMode: false // Optional. Use dark theme, defaults to false
//           }
//       },

//       "custom-binancechainwallet": {
//           display: {
//               logo: "https://lh3.googleusercontent.com/rs95LiHzLXNbJdlPYwQaeDaR_-2P9vMLBPwaKWaQ3h9jNU7TOYhEz72y95VidH_hUBqGXeia-X8fLtpE8Zfnvkwa=w128-h128-e365-rj-sc0x00ffffff",
//               name: "Binance Chain Wallet",
//               description: "Connect to your Binance Chain Wallet"
//           },
//           package: true,
//           connector: async () => {
//               let provider = null;
//               if (typeof window.BinanceChain !== 'undefined') {
//                   provider = window.BinanceChain;
//                   try {
//                       const account = await provider.request({ method: 'eth_requestAccounts' })
//                       console.log(account[0]);
//                   } catch (error) {
//                       throw new Error("User Rejected");
//                   }
//               } else {
//                   throw new Error("No Binance Chain Wallet found");
//               }
//               return provider;
//           }
//       },
//   };
//   return providerOptions;
// };

function Header() {
    const [fundsLoading, setFundsLoading] = useState(false);
    const [darkMode, setDarkMode] = useState((localStorage.getItem("mode") === null || localStorage.getItem("mode") === "light") ? (false) : (true));
    const count = useSelector((state) => state.counter.chain_Id)
    // console.log("count", count);
    const web3Ctx = useContext(Web3Context);
    const marketplaceCtx = useContext(MarketplaceContext);
    const { addToast } = useToasts();
    const { walletAddress, resetApp, setWalletAddress, onConnect } = useWeb3();
    const [userData, setUserData] = useState(null);

    //   const web3Modal = new Web3Modal({
    //       network: "Polygon",
    //     //   cacheProvider: true,s
    //       providerOptions: getProviderOptions(),
    //   });

    //   useEffect(() => {
    //       if (web3Modal.cachedProvider) {
    //           resetApp();
    //       }
    //   }, []);


    //   const subscribeProvider = async (provider) => {
    //       if (!provider.on) {
    //           return;
    //       }
    //       provider.on("close", () => resetApp());
    //       provider.on("accountsChanged", async (accounts) => {
    //           console.log(accounts[0]);
    //           setWalletAddress(accounts[0]);
    //           setWeb3Data({ ...web3Data, address: accounts[0] });
    //           // await this.getAccountAssets();
    //       });
    //       provider.on("chainChanged", async (chainId) => {
    //           // const { web3 } = web3Data;
    //           // const networkId = await web3.eth.net.getId();
    //           // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
    //           // await this.getAccountAssets();
    //       });

    //       provider.on("networkChanged", async (networkId) => {
    //           // const { web3 } = web3Data;
    //           // const chainId = await web3.eth.chainId();
    //           // setWeb3Data({ ...web3Data, chainId: chainId, networkId: networkId });
    //           // await this.getAccountAssets();
    //       });
    //   };

    //   const resetApp = async () => {
    //       // const { web3 } = web3Data;
    //       if (web3 && web3.currentProvider && web3.currentProvider.close) {
    //           await web3.currentProvider.close();
    //       }
    //       setWalletAddress("");
    //       await web3Modal.clearCachedProvider();
    //       // setWeb3Data({ ...INITIAL_STATE });
    //   };

    //   const onConnect = async () => {
    //       try {
    //           const provider = await web3Modal.connect();
    //           await subscribeProvider(provider);
    //           await provider.enable();
    //           setWeb3(new Web3(provider));
    //           const chainId = await provider.request({ method: 'eth_chainId' });
    //           const binanceTestChainId = '0x61'
    //           if (chainId === binanceTestChainId) {
    //               console.log("Bravo!, you are on the correct network");
    //           } else {
    //               try {
    //                   await provider.request({
    //                       method: 'wallet_switchEthereumChain',
    //                       params: [{ chainId: '0x61' }], //0x38 Mainnet 
    //                   });
    //                   console.log("You have succefully switched to Binance main network")
    //               } catch (switchError) {
    //                   // This error code indicates that the chain has not been added to MetaMask.
    //                   if (switchError.code === 4902) {
    //                       try {
    //                           await provider.request({
    //                               method: 'wallet_addEthereumChain',
    //                               params: [
    //                                   {
    //                                       chainId: '0x61',
    //                                       chainName: 'Binance Smart Chain',
    //                                       rpcUrls: ['https://bsc-testnet.public.blastapi.io'],
    //                                       blockExplorerUrls: ['https://bscscan.com/'],
    //                                       nativeCurrency: {
    //                                           symbol: 'BNB',
    //                                           decimals: 18,
    //                                       }
    //                                   }
    //                               ]
    //                           });
    //                       } catch (addError) {
    //                           console.log(addError);
    //                           // alert(addError);
    //                       }
    //                   }
    //                   // alert("Failed to switch to the network")
    //                   return;
    //               }
    //           }

    //           const accounts = await provider.request({ method: 'eth_requestAccounts' });
    //           const account = accounts[0];
    //           setWalletAddress(account);
    //       } catch (e) {
    //           console.log(e);
    //       }
    //   };

    function ellipseAddress(
        address = "",
        width = 10
    ) {
        return `${address.slice(0, width)}...${address.slice(-width)}`;
    }

    useEffect(() => {
        navbarChangeStyle();

        if (localStorage.getItem("mode") === null) {
            localStorage.setItem('mode', "light");

            document.querySelector('#root').classList.add('light');
        }
        else {
            if (localStorage.getItem("mode") === "light")
                document.querySelector('#root').classList.add('light');
            else if (localStorage.getItem("mode") === "dark")
                document.querySelector('#root').classList.remove('light');
        }
    }, []);

    // const connectWalletHandler = async () => {
    //     try {
    //         // Request account access
    //         await window.ethereum.request({ method: 'eth_requestAccounts' });
    //     } catch (error) {
    //         console.error(error);
    //     }
    //     // Load accounts
    //     web3Ctx.loadAccount(web3);
    // };

    const claimFundsHandler = () => {
        marketplaceCtx.contract.methods
            .claimFunds()
            .send({ from: web3Ctx.account })
            .on('transactionHash', (hash) => {
                setFundsLoading(true);
            })
            .on('error', (error) => {
                addToast('Something went wrong when pushing to the blockchain', {
                    appearance: 'error',
                });
                setFundsLoading(false);
            });
    };

    // Event ClaimFunds subscription
    if (!marketplaceCtx.mktIsLoading) {
        marketplaceCtx.contract.events
            .ClaimFunds()
            .on('data', (event) => {
                marketplaceCtx.loadUserFunds(marketplaceCtx.contract, web3Ctx.account);
                setFundsLoading(false);
            })
            .on('error', (error) => {
                console.log(error);
                setFundsLoading(true);
            });
    }

    useEffect(() => {
        if (!marketplaceCtx.mktIsLoading) {
            marketplaceCtx.loadSellers(marketplaceCtx.contract);
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [marketplaceCtx.mktIsLoading]);

    useEffect(() => {
        // //document.querySelector('#root').classList.contains('light')
        // if (!darkMode)
        //     document.querySelector('#root').classList.add('light');//.classList.contains('light')
        // else{
        //     document.querySelector('#root').classList.remove('light');
        // }
        if (!darkMode) {
            document.querySelector('#root').classList.add('light');
            localStorage.setItem('mode', "light");
        }
        else {
            document.querySelector('#root').classList.remove('light');
            localStorage.setItem('mode', "dark");
        }
    }, [darkMode])

    const handleLightDarkMode = () => {
        setDarkMode(!darkMode);
    }

    window.addEventListener('storage', () => {
        if (localStorage.getItem("mode") === "light") {
            document.querySelector('#root').classList.add('light');
            localStorage.setItem('mode', "light");
            setDarkMode(false);
        }
        else if (localStorage.getItem("mode") === "dark") {
            document.querySelector('#root').classList.remove('light');
            localStorage.setItem('mode', "dark");
            setDarkMode(true);
        }
    })
    
    const fetchData = async () => {


        if (walletAddress?.startsWith("0x")) {

            let res = await axios.get(`https://server.nftapi.online/get_user_profile?address=${walletAddress?.toUpperCase()}`)
            // console.log("get_user_profile", res);

            if (res?.data.success == false) {

                // history("/Create_User_profile");
                setUserData(null)

            } else {

                setUserData(res?.data?.data)
            }
        }


    };
    const disconnect = () => {
        // console.log("disconnect call");
        sessionStorage.removeItem("meta-address");
        sessionStorage.removeItem("Web3");


        setWalletAddress("");
    };


    

    const metaAddress = sessionStorage.getItem("meta-address");
    useEffect(() => {
        // console.log("JSON.parse(metaAddress)", JSON.parse(metaAddress));
        if (metaAddress) {
            setWalletAddress(JSON.parse(metaAddress));

        }

        if (walletAddress?.startsWith("0x")) {
            sessionStorage.setItem("meta-address", JSON.stringify(walletAddress));
            fetchData();
        }

    }, [walletAddress]);
    // console.log("walletAddress",walletAddress);


    return (
        <nav className='navbar navbar-expand-lg navbar-dark fixed-top' id='navbar'>
            <div className='container'>
                <Link className='navbar-brand' to='/'>
                    <img className='img-fluid' src='/images/logo.svg' alt='MintSea' width='140' />
                </Link>

                <button
                    className='navbar-toggler'
                    type='button'
                    data-bs-toggle='collapse'
                    data-bs-target='#navbarSupportedContent'
                    aria-controls='navbarSupportedContent'
                    aria-expanded='false'
                    aria-label='Toggle navigation'
                >
                    <span className='navbar-toggler-icon'></span>
                </button>

                <div className='collapse navbar-collapse' id='navbarSupportedContent'>
                    <ul className='navbar-nav ms-auto mb-2 mb-lg-0 flex-lg-row align-items-lg-center'>
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/' exact>
                                Home
                            </NavLink>
                        </li>
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/explore'>
                                Explore
                            </NavLink>
                        </li>
                        {/* <li className='nav-item'>
                            <NavLink className='nav-link' to='/my-assets'>
                                My Assets
                            </NavLink>
                        </li> */}
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/authors'>
                                Authors
                            </NavLink>
                        </li>
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/contact'>
                                Contact
                            </NavLink>
                        </li>
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/mint'>
                                Mint NFT
                            </NavLink>
                        </li>
                        <li className='nav-item' style={{ display: 'flex', justifyContent: "space-between", alignItems: 'center' }}>
                            <i className="las la-moon me-2 text-primary pb-1"></i>
                            <div className="form-check form-switch">
                                <input className="form-check-input me-2" type="checkbox" checked={darkMode} onChange={handleLightDarkMode} style={{ backgroundColor: "#ccc", height: "1.5rem", width: "2.5rem" }} />
                                <label className="form-check-label pt-1" htmlFor="flexSwitchCheckDefault">Night</label>
                            </div>
                        </li>
                        <li className='nav-item'>
                            <NavLink className='nav-link' to='/search'>
                                <i className='las la-search' style={{ marginTop: '0.125rem' }}></i>
                            </NavLink>
                        </li>

                        {walletAddress?.startsWith("0x") ? (
                            <li className='nav-item dropdown'>
                                <NavLink
                                    className='nav-link dropdown-toggle d-flex align-items-center'
                                    id='accountDropdown'
                                    to='/'
                                    role='button'
                                    data-bs-toggle='dropdown'
                                    aria-expanded='false'
                                >
                                    <div style={{ width: '35px', height: '35px' }}>
                                        {
                                            userData == null ? <><Jazzicon address={walletAddress} /></> : <><Avatar alt="" src={`https://server.nftapi.online/uploads/${userData?.image}`} /> </>
                                        }


                                    </div>
                                </NavLink>
                                <ul
                                    className='dropdown-menu dropdown-menu-dark dropdown-menu-end fade-down text-start'
                                    aria-labelledby='accountDropdown'
                                >
                                    <li>
                                        <a
                                            // href={configEtherScanUrl(web3Ctx.networkId, web3Ctx.account)}
                                            className='dropdown-item d-flex align-items-center'
                                            target='_blank'
                                            rel='noopener noreferrer'
                                        >
                                            <i className='las la-chart-bar me-2 text-primary'></i>
                                            Track transactions
                                        </a>
                                    </li>
                                    <li>
                                        <Link
                                            to='/my-assets'
                                            className='dropdown-item d-flex align-items-center'
                                            rel='noopener noreferrer'
                                        >
                                            <i className='las la-user-circle me-2 text-primary'></i>
                                            My Assets
                                        </Link>
                                    </li>
                                    <li>
                                        <Link
                                            to='/User_Profile'
                                            className='dropdown-item d-flex align-items-center'
                                            rel='noopener noreferrer'
                                        >
                                            <i className='las la-user-circle me-2 text-primary'></i>
                                            User Profile
                                        </Link>
                                    </li>
                                    <li>
                                        <Link
                                            to='/User_Collection'
                                            className='dropdown-item d-flex align-items-center'
                                            rel='noopener noreferrer'
                                        >
                                            <i className='las la-user-circle me-2 text-primary'></i>
                                            Collection
                                        </Link>
                                    </li>
                                    <li>
                                        <NavLink className='dropdown-item d-flex' to='/explore'>
                                            <i className='las la-wallet me-2 text-primary'></i>
                                            <div className='ms-0'>
                                                <p className='mb-0 lh-1'>Marketplace Balance</p>
                                                <p className='mb-0 text-primary'>
                                                    {/* {formatPrice(marketplaceCtx.userFunds)} ETH */}
                                                </p>
                                            </div>
                                        </NavLink>
                                    </li>
                                    <li onClick={() => disconnect()} >
                                    <NavLink className='dropdown-item d-flex'to='/' >
                                    <i className='las la-user-circle me-2 text-primary'></i>
                                        LogOut
                                        </NavLink>

                                       

                                    </li>
                                    {/* {marketplaceCtx.userFunds > 0 && !fundsLoading && (
                                        <li className='p-2'>
                                            <button
                                                type='button'
                                                className='btn btn-gradient-primary w-100'
                                                onClick={claimFundsHandler}
                                            >
                                                Claim funds
                                            </button>
                                        </li>
                                    )} */}
                                    {/* {fundsLoading && (
                                        <li>
                                            <span className='d-flex justify-content-center'>
                                                <div className='spinner-border' role='status'>
                                                    <span className='sr-only'></span>
                                                </div>
                                            </span>
                                        </li>
                                    )} */}
                                </ul>
                            </li>
                        ):
                        (
                            <>
                            
                            <li className='nav-item nav-item ms-lg-2'>
                                <button
                                    type='button'
                                    className='btn btn-gradient-primary btn-sm px-3 d-lg-flex align-items-center'
                                    // onClick={connectWalletHandler}
                                    onClick={walletAddress === "" ? onConnect : resetApp}
                                >

                                    {walletAddress === "" ? <> <i className='las la-wallet me-2 mb-1'></i>
                                        Connect your wallet</> : ellipseAddress(walletAddress, 7)}

                                </button>
                            </li>
                            </>

                        )
                    
                    }

                        {/* {!JSON.parse(metaAddress)?.startsWith("0x") && (
                            
                        )} */}
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default Header;
