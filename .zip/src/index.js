import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import Web3Provider from './store/Web3Provider';
import CollectionProvider from './store/CollectionProvider';
import MarketplaceProvider from './store/MarketplaceProvider';
import { ToastProvider } from 'react-toast-notifications';
import * as bootstrap from 'bootstrap';
import { Web3ContextProvider } from './components/Components/web3Context';
import { store } from './Redux/store'
import { Provider } from 'react-redux'
window.bootstrap = bootstrap;

ReactDOM.render(
    
        <Provider store={store}>
            <Web3Provider>
                <CollectionProvider>
                    <MarketplaceProvider>
                        <Web3ContextProvider>
                            <ToastProvider autoDismiss autoDismissTimeout={6000} placement='top-center'>
                                <App />
                            </ToastProvider>
                        </Web3ContextProvider>
                    </MarketplaceProvider>
                </CollectionProvider>
            </Web3Provider>
        </Provider>,

    document.getElementById('root')
);
