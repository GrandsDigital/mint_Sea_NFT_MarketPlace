import React, { useEffect, useState } from "react";
import "./Auth_style.css";
import useWeb3 from "../components/Components/useWeb3";
import axios from "axios";
import Moralis from "moralis";
import { EvmChain } from "@moralisweb3/evm-utils";
import { useSelector } from "react-redux";
import { toHex } from "../Utils/utils";
import profile_placeholder_image from "../Assets/profile_placeholder_image.629dab34.jpg";
import NftItem from "../components/general/NftItem";
import { Jazzicon } from "@ukstv/jazzicon-react";
import { Link, useHistory } from "react-router-dom";
import {
  CreateNFT,
  CreateNFT_ABI,
  nftMarketContractAddress,
  nftMarketContractAddress_Abi,
} from "../Utils/Contract";
import FullScreenLoader from "../components/general/FullScreenLoader";
import { formatDate } from "../helpers/utils";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { toast } from "react-hot-toast";
export default function User_Registration() {
  const { web3, walletAddress } = useWeb3();
  const [UserData, setUserData] = useState(null);
  const [IsSpinner, setIsSpinner] = useState(false);
  const [Address_User, setAddress_User] = useState("");
  const [CollectionArray, setCollectionArray] = useState([]);
  const [getOfferPrice, setgetOfferPrice] = useState(0);
  const [copied, setcopied] = useState(false);
  const history = useHistory();
  const count = useSelector((state) => state.counter.chain_Id);

  const fetchData = async () => {
    if (walletAddress?.startsWith("0x")) {
      let res = await axios.get(
        `https://server.nftapi.online/get_user_profile?address=${walletAddress?.toUpperCase()}`
      );
      // console.log("get_user_profile", res);

      if (res?.data.success == false) {
        // history("/Create_User_profile");
      } else {
        setUserData(res?.data?.data);
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, [walletAddress]);

  const runApp = async () => {
    let imageArray = [];

    try {
      setAddress_User(walletAddress);

      const address = walletAddress;

      let chain;
      if (count == toHex(11155111)) {
        chain = EvmChain.SEPOLIA;
      } else if (count == toHex(80001)) {
        chain = EvmChain.MUMBAI;
      } else if (count == toHex(97)) {
        chain = EvmChain.BSC_TESTNET;
      }
      if (!Moralis.Core.isStarted) {
        await Moralis.start({
          apiKey:
            "gI4QFVnQgnpOIG0CdMSUq7wLkrbEaypx8p28wx2Pohw1EWJUY6Ongt3vHIuovT4Z",
          // ...and any other configuration
        });
      }

      // console.log("Chain",chain);

      let res = await Moralis.EvmApi.nft.getWalletNFTs({
        address,
        chain,
      });

      console.log("getWalletNFTs", res);
      res = res?.jsonResponse?.result;

      let loopLength = res?.length;
      // console.log("Length",res.length);
      let name;
      let symbol;
      let created_date;
      let category;
      let Image_type = "image";
      for (let i = 0; i < loopLength; i++) {
        // console.log("Url", res[i].token_uri);

        let jsonUsrl = res[i].token_uri;
         Image_type = "image";

        name = res[i].name;
        symbol = res[i].symbol;
        created_date = res[i].last_token_uri_sync;
        if (jsonUsrl == null) {
          jsonUsrl = profile_placeholder_image;
          // console.log("Image_is_null");
        } else if (jsonUsrl.endsWith(".json")) {
          jsonUsrl = profile_placeholder_image;
          // console.log("jsonUsrl",jsonUsrl);
        } else if (jsonUsrl.endsWith(".jpg")) {
          jsonUsrl = jsonUsrl;
          // console.log("jsonUsrl",jsonUsrl);
        } else if (
          (jsonUsrl.startsWith("https://ipfs.moralis.io:2053/ipfs/") &&
            jsonUsrl.endsWith(".jpg")) ||
          jsonUsrl.endsWith(".png")
        ) {
          jsonUsrl = jsonUsrl;
        } else if (jsonUsrl.startsWith("https://ipfs.moralis.io:2053/ipfs/")) {
          jsonUsrl = jsonUsrl;
          // let Response= await axios.get(jsonUsrl);
          // Response = Response?.data?.properties?.image?.description
          // jsonUsrl = `https://ipfs.moralis.io:2053/${Response}`

          // console.log("Url",jsonUsrl);

          // let Api = await axios.get(jsonUsrl)
          // console.log("Api", Api.data.properties.image.description);
          // Api = Api.data.properties.image.description
          // jsonUsrl = `https://ipfs.moralis.io:2053/${Api}`
        } else if (jsonUsrl.startsWith("Qm")) {
          let data = `https://skywalker.infura-ipfs.io/ipfs/${jsonUsrl}`;
          let Response = await axios.get(data);
          jsonUsrl = `https://skywalker.infura-ipfs.io/ipfs/${Response.data.properties.image.description}`;
          name = Response.data.properties.name.description;
          category = Response.data.properties.category.description;
          Image_type = Response.data.properties.image.type;
          console.log("Image_type", Image_type);
        } else {
          jsonUsrl = jsonUsrl;
          Image_type="image"
        }

        let owner_of = res[i].owner_of;
        let token_address = res[i].token_address;
        let amount = res[i].amount;

        let token_id = res[i].token_id;

        let finalUrl;
        // =await axios.get(jsonUsrl);
        // finalUrl = finalUrl.data.image;
        imageArray = [
          ...imageArray,
          {
            url: finalUrl,
            name: name,
            owner_of: owner_of,
            token_address: token_address,
            amount: amount,
            symbol: symbol,
            token_id: token_id,
            jsonUsrl: jsonUsrl,
            created_date: created_date,
            category: category,
            Image_type: Image_type,
          },
        ];

        setCollectionArray(imageArray);
      }
    } catch (error) {
      console.log(error);
    }

    // } else {

    // }

    // setCollectionArray(res.data.result)
  };

  useEffect(() => {
    runApp();
  }, []);

  const makeOffer = async (id, items) => {
    try {
      if (getOfferPrice != 0) {
        setIsSpinner(true);
        let nftMarketContractOf = new web3.eth.Contract(
          nftMarketContractAddress_Abi,
          nftMarketContractAddress
        );
        console.log("CreateNFT", nftMarketContractAddress);
        let nftContractO1f = new web3.eth.Contract(CreateNFT_ABI, CreateNFT);
        await nftContractO1f.methods
          .setApprovalForAll(nftMarketContractAddress, true)
          .send({
            from: walletAddress,
          });

        let value = web3.utils.toWei(getOfferPrice.toString());
        let hash = await nftMarketContractOf.methods.makeOffer(id, value).send({
          from: walletAddress,
        });
        hash = hash.transactionHash;
        setTimeout(async () => {
          let OfferCount = await nftMarketContractOf.methods
            .offerCount()
            .call();
          console.log("OfferCount", OfferCount);
          let Offer = await nftMarketContractOf.methods
            .offers(OfferCount)
            .call();
          console.log("Offer", Offer.offerId);

          let postapiPushdata = await axios.post(
            "https://server.nftapi.online/open_marketplace",
            {
              useraddress: walletAddress,
              itemId: Offer.offerId,
              nftContract: CreateNFT,
              tokenId: id,
              owner: items.owner_of,
              price: getOfferPrice,
              sold: items.Image_type,
              isOnAuction: 0,
              bidEndTime: UserData?.image,
              name: items.name,
              url: items.jsonUsrl,
              txn: hash,
              category: items.category,
              edate: new Date(),
              Blockchain:
                count == toHex(97)
                  ? "Binance"
                  : count == toHex(11155111)
                  ? "Ethereum"
                  : "Polygon",
            }
          );
          console.log("postapiPushdata", postapiPushdata);
          setIsSpinner(false);
          history.push("/explore");
        }, 5000);
        // toast.success("")
      } else {
        toast.error("Please Enter Amount First!");
        setIsSpinner(false);
      }
    } catch (error) {
      setIsSpinner(false);

      console.log(error);
    }
  };

  return (
    <div>
      {IsSpinner ? <FullScreenLoader heading="loading" /> : null}
      <main className="pt-[5.5rem] lg:mt-24">
        {/* Banner */}
        <div className="relative">
          <img
            src={
              UserData !== null
                ? `https://server.nftapi.online/uploads/${UserData?.image}`
                : "img/user/banner.jpg"
            }
            alt="banner"
            className="h-[18.75rem] object-cover"
            width="100%"
          />
        </div>
        {/* end banner */}
        {/* Profile */}
        <section className="relative bg-light-base pb-12 pt-28 dark:bg-jacarta-800">
          {/* Avatar */}
          <div className="absolute left-1/2 top-0 z-10 flex -translate-x-1/2 -translate-y-1/2 items-center justify-center">
            <figure className="relative">
              <img
                src={
                  UserData !== null
                    ? `https://server.nftapi.online/uploads/${UserData?.image}`
                    : "img/user/user_avatar.gif"
                }
                alt="collection avatar"
                className="rounded-xl border-[5px] border-white dark:border-jacarta-600"
                style={{ width: "200px", height: "150px" }}
              />
              <div
                className="absolute -right-3 bottom-0 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-green dark:border-jacarta-600"
                data-tippy-content="Verified Collection"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  width={24}
                  height={24}
                  className="h-[.875rem] w-[.875rem] fill-white"
                >
                  <path fill="none" d="M0 0h24v24H0z" />
                  <path d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z" />
                </svg>
              </div>
            </figure>
          </div>
          <div className="container">
            <div className="text-center">
              <h2 className="mb-2 font-display text-4xl font-medium text-jacarta-700 dark:text-white">
                {UserData !== null ? UserData?.username : "UserName"}
              </h2>
              <div className="mb-8 inline-flex items-center justify-center rounded-full border border-jacarta-100 bg-white py-1.5 px-4 dark:border-jacarta-600 dark:bg-jacarta-700">
                <button
                  className="js-copy-clipboard max-w-[10rem] select-none overflow-hidden text-ellipsis whitespace-nowrap dark:text-jacarta-200"
                  data-tippy-content="Copy"
                >
                  <span className=" text-muted">
                    <CopyToClipboard
                      text={UserData?.address}
                      onCopy={() => setcopied(true)}
                    >
                      <span>
                        {UserData !== null
                          ? UserData?.address
                          : "0x23922cdFa9616A9c5175C0c08f1fc660924eeBdE"}
                      </span>
                    </CopyToClipboard>
                    {copied ? toast.success("Copied") : null}
                  </span>
                </button>
              </div>
              <p className="mx-auto mb-2 max-w-xl text-lg text-muted text-sm ">
                I make art with the simple goal of giving you something pleasing
                to look at for a few seconds.
              </p>
            </div>
          </div>
        </section>

        <section className="relative py-24 pt-20">
          <picture className="pointer-events-none absolute inset-0 -z-10 dark:hidden">
            <img
              src="img/gradient_light.jpg"
              alt="gradient"
              className="h-full w-full"
            />
          </picture>
          <div className="container">
            <div className="tab-content">
              {/* On Sale Tab */}
              <div
                className="tab-pane fade show active"
                id="on-sale"
                role="tabpanel"
                aria-labelledby="on-sale-tab"
              >
                {/* Filters */}
                <div className="mb-8 flex flex-wrap items-center justify-between">
                  <div className="flex flex-wrap items-center">
                    {/* Collections */}
                    <div className="my-1 mr-2.5">
                      <button className=" group group flex h-9 items-center rounded-lg border border-jacarta-100 bg-white px-4 font-display text-sm font-semibold text-jacarta-700 transition-colors hover:border-transparent hover:bg-accent hover:text-white dark:border-jacarta-600 dark:bg-jacarta-700 dark:text-white dark:hover:bg-accent">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          width={24}
                          height={24}
                          className="mr-1 h-4 w-4 fill-jacarta-700 transition-colors group-hover:fill-white dark:fill-jacarta-100"
                        >
                          <path fill="none" d="M0 0h24v24H0z" />
                          <path d="M7 5V2a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v3h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h4zm2 8H4v6h16v-6h-5v3H9v-3zm11-6H4v4h5V9h6v2h5V7zm-9 4v3h2v-3h-2zM9 3v2h6V3H9z" />
                        </svg>
                        <span>Collections</span>
                      </button>
                      <div
                        className="dropdown-menu z-10 hidden min-w-[280px] whitespace-nowrap rounded-xl bg-white py-4 px-2 text-left shadow-xl dark:bg-jacarta-800"
                        aria-labelledby="onSaleCollectionsFilter"
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="row mixitUpContainer gy-4 mb-5 align-items-stretch">
                  {CollectionArray.map((items, index) => {
                  
                    return (
                      <>
                        <div
                          className={`col-xl-3 col-lg-4 col-md-6 mix `}
                          key={index}
                        >
                          {/* <NftItem {...items} index={index} /> */}
                          {/* <img src={items.jsonUsrl} alt="" /> */}
                          <div className="card-body p-3 position-relative">
                            <div className="position-relative mb-4 shadow">
                              <div className="author z-index-20">
                                <div
                                  className="ms-3 rounded-circle bd-3 border-dark"
                                  style={{ width: "45px", height: "45px" }}
                                >
                                  {UserData != null ? (
                                    <>
                                      <img
                                        src={
                                          UserData !== null
                                            ? `https://server.nftapi.online/uploads/${UserData?.image}`
                                            : "img/user/banner.jpg"
                                        }
                                        style={{
                                          borderRadius: "50%",
                                          width: "4rem",
                                          height: "3rem",
                                        }}
                                        alt=""
                                      />
                                    </>
                                  ) : (
                                    <>
                                      <Jazzicon address={items.owner_of} />
                                    </>
                                  )}
                                </div>
                                <span className="icon bg-primary text-white me-1">
                                  <i className="las la-check-double"></i>
                                </span>
                              </div>
                              <div className="card-img-holder rounded overflow-hidden">
                                {/* <Link className="text-reset" to={`/assets}`}> */}
                                {items.Image_type.startsWith("image") ? (
                                  <>
                                    {" "}
                                    <img
                                      className="img-fluid rounded w-100"
                                      src={items.jsonUsrl}
                                      // alt={title}
                                    />{" "}
                                  </>
                                ) : items.Image_type.startsWith("video") ? (
                                  <>
                                    <video
                                      className="VideoInput_video"
                                      width="100%"
                                      muted={true}
                                      loop
                                      autoPlay={true}
                                      controls={true}
                                      src={items.jsonUsrl}
                                    />
                                  </>
                                ) : (
                                  <>
                                  <audio controls={true} loop muted={true}
                                    autoPlay={true} className="audio-element"  src={items.jsonUsrl} />
                                  
                                  </>
                                )}
                               
                                {/* </Link> */}
                              </div>
                            </div>
                            <p className="fw-bold mb-3">
                              <Link className="text-reset" to={`/assets`}>
                                {items?.name}
                              </Link>
                            </p>
                            <div className="d-flex justify-content-between">
                              <p className="fw-bold mb-3 text-reset">
                                Token ID
                              </p>{" "}
                              <p className="fw-bold mb-3">
                                <Link className="text-reset" to={`/assets`}>
                                  {items?.token_id}
                                </Link>
                              </p>
                            </div>

                            {/* <NftCategory category={category} /> */}
                            <p className="text-muted mb-2">
                              This is your item, you can put it on sale
                            </p>
                            <div
                              className="input-group"
                              // onSubmit={(e) =>
                              //   makeOfferHandler(e, id, nftKey)
                              // }
                            >
                              <button
                                type="submit"
                                className="btn btn-primary rounded-sm me-2"
                                onClick={() =>
                                  makeOffer(items?.token_id, items)
                                }
                              >
                                Offer
                              </button>
                              <input
                                type="number"
                                step="0.001"
                                min="0.0000000000000000000000001"
                                placeholder={
                                  count == toHex(97)
                                    ? "BNB..."
                                    : count == toHex(80001)
                                    ? "MATIC..."
                                    : "ETH..."
                                }
                                className="form-control py-1 rounded-sm"
                                onChange={(e) =>
                                  setgetOfferPrice(e.target.value)
                                }
                                // ref={priceRefs.current[nftKey]}
                              />
                            </div>

                            <div className="my-3 pt-1 bg-body rounded-pill"></div>
                            <p className="text-muted fw-normal mb-0 text-sm d-flex align-items-center">
                              <i className="la-sm text-primary las la-clock mx-1 mt-1 text-primary"></i>
                              Created
                              <span className="text-primary mx-2">
                                {/* {items.created_date} */}
                                {formatDate(items.created_date)}
                              </span>{" "}
                              ago
                            </p>
                          </div>
                        </div>
                      </>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
